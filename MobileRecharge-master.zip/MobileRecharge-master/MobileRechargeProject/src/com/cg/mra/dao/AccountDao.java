package com.cg.mra.dao;

import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.MobileNumberNotFoundException;

public interface AccountDao {
	public Account getAccountDetails(String mobileNumber) throws MobileNumberNotFoundException;
	public double rechargeAccount(String mobileNumber,double rechargeAmount) throws MobileNumberNotFoundException;
}
