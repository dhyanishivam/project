package com.cg.mra.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MobileRechargeTesting {


	@Test(expected=com.cg.mra.exceptions.MobileNumberNotFoundException.class)
	public void whenMobileNumberNotFoundForAccountBalanceEnquiry() throws Exception {
		AccountDao accountdao = new AccountDaoImpl();
		AccountService accountservice = new AccountServiceImpl(accountdao);
		accountservice.getAccountDetails("9874563210");
	}
	
	@Test(expected=com.cg.mra.exceptions.MobileNumberNotFoundException.class)
	public void whenMobileNumberNotFoundForRechargingAccount() throws Exception
	{
		AccountDao accountdao = new AccountDaoImpl();
		AccountService accountservice = new AccountServiceImpl(accountdao);
		accountservice.rechargeAccount("9999955555", 500);
	}
	
	@Test
	public void allInputsAreCorrectForAccountBalanceEnquiry() throws Exception
	{
		AccountDao accountdao = new AccountDaoImpl();
		AccountService accountservice = new AccountServiceImpl(accountdao);
		accountservice.getAccountDetails("9010210131");
		assertEquals(200, accountservice.getAccountDetails("9010210131").getAccountBalance(),0.01);
		
	}
	@Test
	public void allInputsAreCorrectForRechargingAccount() throws Exception
	{
		AccountDao accountdao = new AccountDaoImpl();
		AccountService accountservice = new AccountServiceImpl(accountdao);
		accountservice.rechargeAccount("9010210131", 500);
		assertEquals(700, accountservice.getAccountDetails("9010210131").getAccountBalance(),0.01);
	}
	

}
