package com.cg.mra.exceptions;

public class MobileNumberNotFoundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	
	

}
