package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.exceptions.MobileNumberNotFoundException;

public class AccountServiceImpl implements AccountService {

	AccountDao accountdao;
	
	public AccountServiceImpl(AccountDao accountdao) {
		super();
		this.accountdao = accountdao;
	}

	@Override
	public Account getAccountDetails(String mobileNumber) throws MobileNumberNotFoundException {
		Account account = accountdao.getAccountDetails(mobileNumber);
		if(account==null) {
			throw new MobileNumberNotFoundException();
		}
		return account;
	}

	@Override
	public double rechargeAccount(String mobileNumber, double rechargeAmount) throws MobileNumberNotFoundException {
		Account account = accountdao.getAccountDetails(mobileNumber);
		if(account!=null) {
			return accountdao.rechargeAccount(mobileNumber, rechargeAmount);
		}
		throw new MobileNumberNotFoundException();
		
	}

}
