package com.cg.mra.ui;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	private static Scanner sc = new Scanner(System.in);
	private static AccountDao accountdao = new AccountDaoImpl();
	private static AccountService accountService = new AccountServiceImpl(accountdao);

	public static void main(String[] args) {
		while(true)
		{
			System.out.println("1) Account Balance Enquiry");
			System.out.println("2) Recharge Account");
			System.out.println("3) Exit");
			System.out.println("Enter your choice :");
			int choice = sc.nextInt();
			switch(choice)
			{
			case 1:balanceEnquiry();
				break;
			case 2:rechargeAccount();
				break;
			case 3:sc.close();
				System.exit(0);
			default:System.out.println("You entered wrong choice");
			}
		}
	}
	private static void balanceEnquiry() {
		System.out.println("Enter Mobile No :");
		String mobileNo = sc.next();
		while(!(validateMobileNo(mobileNo)))
		{
			System.out.println("Mobile Number not valid enter again");
			mobileNo = sc.next();
		}
		Account account=null;
		try {
			account = accountService.getAccountDetails(mobileNo);
			System.out.println("Your Current Balance is Rs."+account.getAccountBalance());
		} catch (Exception e) {
			System.out.println("Given Account Id does Not Exists");
		}
		
		
	}

	private static boolean validateMobileNo(String mobileNo) {
		Pattern mobilePattern = Pattern.compile("[6789]{1}[0-9]{9}");
		Matcher m = mobilePattern.matcher(mobileNo);
		if(m.matches())
		{
			return true;
		}
		return false;
				
		
	}
	private static void rechargeAccount() {
		System.out.println("Enter Mobile No :");
		String mobileNo = sc.next();
		while(!(validateMobileNo(mobileNo)))
		{
			System.out.println("Mobile Number not valid enter again");
			mobileNo = sc.next();
		}
		System.out.println("Enter Recharge Amount :");
		double rechargeAmount = sc.nextDouble();
		while(!(validateAmount(rechargeAmount)))
		{
			System.out.println("Recharge amount must be greater than 0");
			rechargeAmount = sc.nextDouble();
		}
		double balance=0;
		try {
			balance = accountService.rechargeAccount(mobileNo, rechargeAmount);
			System.out.println("Available balance is "+balance);
		} catch (Exception e) {
			System.out.println("Cannot Recharge Account as given mobile no does not exists");
		}
		
		
	}
	private static boolean validateAmount(double rechargeAmount) {
		if(rechargeAmount>0)
		{
			return true;
		}
		return false;
	}


	
}
